import React from 'react';
import { SortableContainer } from '../../src/index.js';

export default SortableContainer;

